//
//  ListMovieInteractorTest.swift
//  KokoEstandares VIP SwiftTests
//
//  Created by Sergio on 3/11/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import XCTest
@testable import KokoEstandares_VIP_Swift

class ListMovieInteractorTest: XCTestCase {
    
    var interactorListTest: ListMovieInteractor!
    var movieArray: [MovieEntity] = []
    
    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        setFakeData()
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        interactorListTest.presenter?.interactor(interactorListTest, didFetch: movieArray)
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    func setFakeData() {
        interactorListTest = ListMovieInteractor(withApiWorker: ListMoviewWorkerWS())
        for _ in 0..<2 {
            
            let movieInfo = MovieEntity(title: "1917",
                                        vote_average: "8.1",
                                        poster_path: "https://image.tmdb.org/t/p/w500/AuGiPiGMYMkSosOJ3BQjDEAiwtO.jpg",
                                        release_date: "2019-12-10",
                                        overview: "At the height of the First World War, two young British soldiers, Schofield and Blake are given a seemingly impossible mission. In a race against time, they must cross enemy territory and deliver a message that will stop a deadly attack on hundreds of  own brother among them.",
                                        idMovie: "530915",
                                        videoKey: "0")
            
            movieArray.append(movieInfo)
            
        }
    }
    
    

}
