//
//  Hud.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 3/9/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit
import NVActivityIndicatorView

class Hud: NSObject {
    
    //Var
    var backGroundView:UIView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
    var indicator:NVActivityIndicatorView = NVActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 64, height: 68), type: .ballBeat, color: .white, padding: 0)
    
    
    //Create the view with params
    func showInView(view:UIView, type:NVActivityIndicatorType, text:String, colorBackground: UIColor, colorTypeAndText: UIColor) {
        indicator.type = type
        backGroundView = UIView(frame: view .bounds)
        backGroundView.backgroundColor = colorBackground
        backGroundView.alpha = 0.7
        //add the backgrond view to the view
        view.addSubview(backGroundView)
        indicator.center = backGroundView.center
        indicator.color = colorTypeAndText
        //add the activityIndicator to the backGroundView
        backGroundView.addSubview(indicator)
        indicator.startAnimating()
        backGroundView.translatesAutoresizingMaskIntoConstraints = false
        let blockTrailing = NSLayoutConstraint(item: backGroundView, attribute: .trailing, relatedBy: .equal, toItem: view, attribute: .trailing, multiplier: 1.0, constant: 0.0)
        let blockLeading = NSLayoutConstraint(item: backGroundView, attribute: .leading, relatedBy: .equal, toItem: view, attribute: .leading, multiplier: 1.0, constant: 0.0)
        let blockBottom = NSLayoutConstraint(item: backGroundView, attribute: .bottom, relatedBy: .equal, toItem: view, attribute: .bottom, multiplier: 1.0, constant: 0.0)
        let blockTop = NSLayoutConstraint(item: backGroundView, attribute: .top, relatedBy: .equal, toItem: view, attribute: .top, multiplier: 1.0, constant: 0.0)
        view.addConstraints([blockTrailing, blockLeading, blockBottom, blockTop])
        
        
        indicator.translatesAutoresizingMaskIntoConstraints = false;
        
        
        let indicatorWidth = NSLayoutConstraint(item: indicator, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 64.0)
        
        let indicatorHeight = NSLayoutConstraint(item: indicator, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1.0, constant: 68.0)
        
        indicator.centerXAnchor.constraint(equalTo: backGroundView.centerXAnchor).isActive = true
        indicator.centerYAnchor.constraint(equalTo: backGroundView.centerYAnchor).isActive = true
        indicator.addConstraints([indicatorWidth, indicatorHeight])
        
        if text.count > 0 {
            //Create the label text with the string
            let textLabel = UILabel(frame: CGRect(x: 8, y: 72, width: backGroundView.frame.size.width - 16, height: 0))
            textLabel.text = text
            textLabel.numberOfLines = 0;
            textLabel.lineBreakMode = .byWordWrapping;
            textLabel.textAlignment = .center;
            textLabel.textColor = colorTypeAndText;
            textLabel.font = UIFont.boldSystemFont(ofSize: 18)
            backGroundView.addSubview(textLabel)
            
            textLabel.translatesAutoresizingMaskIntoConstraints = false;
            
            let labelTop = NSLayoutConstraint(item: textLabel, attribute: .top, relatedBy: .equal, toItem: indicator, attribute: .top, multiplier: 1.0, constant: 72.0)
            
            let labelTrailling = NSLayoutConstraint(item: textLabel, attribute: .trailing, relatedBy: .equal, toItem: backGroundView, attribute: .trailing, multiplier: 1.0, constant: -8)
            
            let labelLeading = NSLayoutConstraint(item: textLabel, attribute: .leading, relatedBy: .equal, toItem: backGroundView, attribute: .leading, multiplier: 1.0, constant: 8)
            
            textLabel.centerXAnchor.constraint(equalTo: backGroundView.centerXAnchor).isActive = true
            
            backGroundView.addConstraints([labelTop, labelTrailling, labelLeading])
        }
    }
    
    func dissmiss() {
        backGroundView.removeFromSuperview()
    }

}
