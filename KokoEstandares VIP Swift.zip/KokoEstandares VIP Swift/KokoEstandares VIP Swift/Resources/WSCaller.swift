//
//  WSCaller.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 1/30/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import Foundation
import Alamofire


class WSCaller:ListMovieInteractorProtocol  {
    func saveFavoriteMovie(movie: ListViewModel, tag: (Int)) {
        
    }
    
    func saveFavoriteMovie(movie: ListViewModel) {
        
    }
    
    func startAction() {
        
    }
    
    func startAction(page: (String)) {
        
    }
    
    func searchAction() {
        
    }
    
    func getMovieListWS() {
        let url = URL(string: "\(Constants.Constants.URL_UPCOMING_MOVIES_START)" + "\(Constants.Constants.API_KEY_TMDB)" + "\(Constants.Constants.URL_UPCOMING_MOVIES_END)" + "1")
        
        AF.request(url!).responseJSON { response in
            debugPrint(response)
        }
    }
    
    
}
