//
//  RealmManager.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/28/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import Foundation
import  RealmSwift

class RealmManager {
    let realm = try? Realm()
      
    // delete particular object
    func deleteObject(objs : Object) {
       try? realm!.write ({
            realm?.delete(objs)
    })
    }
      
     //Save array of objects to database
    func saveObjects(objs: Object) {
        try? realm!.write ({
            // If update = false, adds the object
            realm?.add(objs, update: Realm.UpdatePolicy(rawValue: 2)!)
        })
    }
      
     //Returs an array as Results<object>?
//    func getObjects(type: Object.Type) -> Results<Object>? {
//        return realm!.objects(type)
//    }
  
}
