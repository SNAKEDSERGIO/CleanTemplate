//
//  RealmEntity.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/26/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import Foundation
import RealmSwift

class SaveFavorites: Object {
    @objc dynamic var title: String? = ""
    @objc dynamic var vote_average: String? = ""
    @objc dynamic var poster_path: String? = ""
    @objc dynamic var release_date: String? = ""
    @objc dynamic var overview: String? = ""
    @objc dynamic var idMovie: String? = ""
    @objc dynamic var videoKey: String? = ""
}

class ListFavorites: Object {
    let favoritesList = List<SaveFavorites>()
}

extension SaveFavorites {
    func writeToRealm(){
        try! realm?.write {
            realm?.add(self)
        }
    }
    
    func deleteObjectRealm() {
        try! realm?.write {
            realm?.delete(self)
        }
    }
    
    func getObjects()->[SaveFavorites]{
        let realmResults = realm?.objects(SaveFavorites.self)
        return Array(realmResults!)
    }
}


