//
//  Builder.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 1/28/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import Foundation
import UIKit
import RealmSwift

class ListBuilder {
    
    class func builderList(configView view:ListMoviesView) {
        
        //MARK: Initialise components.
        let presenter = ListMoviePresenter()
        ///Funciones WS
        let interactor = ListMovieInteractor(withApiWorker: ListMoviewWorkerWS())
        
        ///Funciones 1 elemento
//        let interactor = ListMovieInteractor(withApiWorker: ListMoviewWorker())
        
        //MARK: link VIP components.
        view.interactor = interactor
        view.presenter = presenter;
        presenter.view = view
        interactor.presenter = presenter
        
        let realm = try! Realm()
        
    }
    
}
