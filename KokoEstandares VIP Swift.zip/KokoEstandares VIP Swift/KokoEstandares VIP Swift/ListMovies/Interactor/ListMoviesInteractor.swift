//
//  ListMoviesInteractor.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 1/24/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import Foundation
import UIKit
import RealmSwift

/// List Movie Interactor Protocol
protocol ListMovieInteractorProtocol {
    ///Funciones WS
    func startAction(page:(String))
    
    ///Funciones 1 elemento
//    func startAction()
    func searchAction()
    
    //Funcion Realm
    func saveFavoriteMovie(movie:ListViewModel, tag:(Int))
    
}

/// List Movie Interactor
class ListMovieInteractor: ListMovieInteractorProtocol {
    
    var presenter:ListMoviePresenterProtocol?
    ///Funciones 1 elemento
//    private var movieEntity:MovieEntity?
//    private let apiWorker: ListMovieWorkerProtocol
    
    ///Funciones WS
    private var movieEntity:[MovieEntity]?
    private let apiWorker: ListMoviewWorkerWS
    
    ///Funciones WS
    required init(withApiWorker apiWorker:ListMoviewWorkerWS) {
        self.apiWorker = apiWorker
    }
    
    func startAction(page:(String)) {
        apiWorker.getMovieList(page: page, callBack: { [unowned self] (movieEntityVar) in
            self.movieEntity = movieEntityVar
            self.presenter?.interactor(self, didFetch: movieEntityVar)
        })
    }
    
    func searchAction() {
        presenter?.searchAction()
    }
    
    //Funcion Realm
    func saveFavoriteMovie(movie:ListViewModel, tag: (Int)) {
        let movieToSave = SaveFavorites()
        movieToSave.title = movie.title
        movieToSave.idMovie = movie.idMovie
        movieToSave.overview = movie.overview
        movieToSave.poster_path = movie.poster_path
        movieToSave.release_date = movie.release_date
        movieToSave.vote_average = movie.vote_average
        movieToSave.videoKey = movie.videoKey

//        print("movie title: \(movieToSave.title ?? "")")
//        let listToSave = ListFavorites()
//        listToSave.favoritesList.append(movieToSave)
//        movieToSave.writeToRealm()
        movieToSave.writeToRealm()
        
        self.presenter?.saveFav(self, tag: tag)
        
    }
    
    ///Funciones 1 elemento
//    required init(withApiWorker apiWorker:ListMoviewWorker) {
//        self.apiWorker = apiWorker
//    }
//
//    func startAction() {
//        apiWorker.initMovieList(callBack: { [unowned self] (movieEntityVar) in
//            self.movieEntity = movieEntityVar
//            self.presenter?.interactor(self, didFetch: movieEntityVar)
//        })
//    }
    
}
