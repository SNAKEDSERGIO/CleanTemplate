//
//  ListMovieWSEntity.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/4/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import Foundation

struct Results: Decodable {
    var title: String
    var vote_average: String
    var poster_path: String
    var release_date: String
    var overview: String
    var idMovie: String
    var videoKey: String
}
