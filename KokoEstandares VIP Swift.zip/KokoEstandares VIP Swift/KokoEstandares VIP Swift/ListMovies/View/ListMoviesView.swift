//
//  ListMoviesView.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 1/23/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit
import SDWebImage
import RealmSwift
import NVActivityIndicatorView
 
protocol ListMovieProtocol: class {
    var presenter: ListMoviePresenterProtocol? { get set }
    var interactor: ListMovieInteractorProtocol? { get set }
    
    // Update UI with value returned.
    /// Set the view Object of Type MovieEntity
    ///Funciones WS
    func set(viewModel: [ListViewModel])
    
    //Un solo elemento
//    func set(viewModel: ListViewModel)
    
    func searchAction()
    
    func saveFavMovie(tag:Int)
    
    func saveFav(tag:(Int))
}


class ListMoviesView: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    @IBOutlet weak var movieListCollectionView: UICollectionView!
    @IBOutlet weak var headerView: UIView!
    
    var presenter: ListMoviePresenterProtocol?
    var interactor: ListMovieInteractorProtocol?
    var listViewArray: [ListViewModel] = []
    let hud = Hud()
//    var getFavList = [SaveFavorites]
    
    var pageNumber:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Hud init
        hud.showInView(view: self.view, type: .audioEqualizer, text: "Loading...", colorBackground: UIColor.black, colorTypeAndText: UIColor.white)
        //MoviesCell
        movieListCollectionView.delegate = self
        movieListCollectionView.dataSource = self
        
        ///Funciones 1 elemento
//        interactor?.startAction()
    
        ///Funciones WS
        ListBuilder.builderList(configView: self)
        pageNumber = 1
        interactor?.startAction(page: "\(pageNumber)")
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        headerView.layer.shadowColor = UIColor(red: 0.0 / 255.0, green: 32.0 / 255.0, blue: 56.0 / 255.0, alpha: 0.60).cgColor
        headerView.layer.shadowOffset = CGSize(width: 1, height: 2)
        headerView.layer.shadowOpacity = 1
        headerView.layer.shadowRadius = 5
    }
    
    override func viewWillAppear(_ animated: Bool) {
//        let checkRealm = SaveFavorites()
//        let checkArray = checkRealm.getObjects()
//        print(checkArray)
    }
    
    // Mark: - IBActions
    
    @IBAction func searchAction(_ sender: Any) {
        let vc = SearchViewController(nibName: "SearchViewController", bundle: nil)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    // Mark: - UICollection Delegate
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listViewArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let nib = UINib(nibName: "ListMoviesCollectionViewCell", bundle: nil)
        movieListCollectionView.register(nib, forCellWithReuseIdentifier: "MoviesCell")
        let cell = movieListCollectionView.dequeueReusableCell(withReuseIdentifier: "MoviesCell", for: indexPath as IndexPath) as! ListMoviesCollectionViewCell
        let movieModel = listViewArray[indexPath.row]
        cell.movieImage.sd_setImage(with: URL(string: Constants.Constants.URL_POSTER_IMAGE + movieModel.poster_path), completed: nil)
        cell.movieImage.layer.cornerRadius = 5
        cell.heartButton.tag = indexPath.row
        cell.viewForCell = self
//        cell.movieImage.sd_setImage(with: URL(string: movieModel.poster_path), completed: nil)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let movieModel = listViewArray[indexPath.row]
        let vc = MovieDetailViewController(nibName: "MovieDetailViewController", bundle: nil)
        vc.movieInfo = movieModel
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if (indexPath.row == listViewArray.count - 1) && pageNumber < 4 {
            pageNumber = pageNumber + 1
            interactor?.startAction(page: "\(pageNumber)")
        }
    }
}

// MARK: - extending ListView to implement it's protocol

extension ListMoviesView: ListMovieProtocol {
   ///Funciones WS
    func set(viewModel: [ListViewModel]) {
        for i in 0..<viewModel.count {
            listViewArray.append(viewModel[i])
        }
        movieListCollectionView.reloadData()
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) {
            //Hud dissmiss
            self.hud.dissmiss()
        }
    }
    
//    func set(viewModel: ListViewModel) {
//        listViewArray.append(viewModel)
//        movieListCollectionView.reloadData()
//    }
    
    func searchAction() {
        print("Imprime")
    }
    
    func saveFavMovie(tag:Int) {
        print("tag: \(tag)")
        interactor?.saveFavoriteMovie(movie: listViewArray[tag], tag:tag)
    }
    
    func saveFav(tag:(Int)) {
        let indexPath = IndexPath(item: tag, section: 0)
        let cell = self.movieListCollectionView.cellForItem(at: indexPath) as! ListMoviesCollectionViewCell
        DispatchQueue.main.async {
            cell.heartButton.setImage(UIImage(systemName: "suit.heart.fill"), for: .normal)
        }
        
    }
}
