//
//  ListMoviesCollectionViewCell.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 1/23/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

class ListMoviesCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var movieImage: UIImageView!
    @IBOutlet weak var heartButton: UIButton!
    weak var viewForCell: ListMovieProtocol?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    //Mark: - IBAction
    @IBAction func heartAction(_ sender: Any) {
        let button = sender as? UIButton
        viewForCell?.saveFavMovie(tag: button!.tag)
    }
}
