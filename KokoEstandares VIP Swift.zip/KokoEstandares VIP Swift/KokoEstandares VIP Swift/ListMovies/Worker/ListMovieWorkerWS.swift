//
//  ListMovieWorkerWS.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 1/31/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import Foundation
import Alamofire


protocol ListMovieWorkerProtocolWS {
    func getMovieList(page:(String), callBack:@escaping ([MovieEntity]) -> Void)
}

class ListMoviewWorkerWS: ListMovieWorkerProtocolWS {
    func getMovieList(page:(String), callBack:@escaping ([MovieEntity]) -> Void) {
        
        let url = URL(string: "\(Constants.Constants.URL_UPCOMING_MOVIES_START)" + "\(Constants.Constants.API_KEY_TMDB)" + "\(Constants.Constants.URL_UPCOMING_MOVIES_END)" + page)!

                AF.request(url).validate().responseJSON { response in
                    switch response.result {
                        case .success:
                            if let JSON = response.value as? [String: Any] {
                                let data = JSON["results"] as! [NSDictionary]
                                var movieArray: [MovieEntity] = []
                                print(data)
                                for i in 0..<data.count {
                                    
                                    let idMovie = data[i].object(forKey: "id")
                                    let title = data[i].object(forKey: "title")
                                    let vote_average = data[i].object(forKey: "vote_average")
                                    let poster_path = data[i].object(forKey: "poster_path")
                                    let release_date = data[i].object(forKey: "release_date")
                                    let overview = data[i].object(forKey: "overview")
                                    let videoKey = data[i].object(forKey: "video")
                                    
                                    let movieInfo = MovieEntity(title: (title as? String) ?? "",
                                                                vote_average: "\(vote_average ?? "")",
                                                                poster_path: (poster_path as? String) ?? "",
                                                                release_date: (release_date as? String) ?? "",
                                                                overview: (overview as? String) ?? "",
                                                                idMovie: "\(idMovie ?? "")",
                                                                videoKey: "\(videoKey ?? "")")
                                    
                                    movieArray.append(movieInfo)
                                }
                                
                                callBack(movieArray)
                            }
                        case .failure(let error):
                            print(error)
                        }
                }
        
    }
}
