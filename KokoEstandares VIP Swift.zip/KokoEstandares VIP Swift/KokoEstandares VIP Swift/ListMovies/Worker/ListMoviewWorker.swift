//
//  ListMoviewWorker.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 1/30/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import Foundation

protocol ListMovieWorkerProtocol {
    func initMovieList(callBack:(MovieEntity) -> Void)
}

class ListMoviewWorker: ListMovieWorkerProtocol{
    
    func initMovieList(callBack:(MovieEntity) -> Void) {
        let movieEntity = MovieEntity(title: "1917",
                                      vote_average: "8.1",
                                      poster_path: "https://image.tmdb.org/t/p/w500/AuGiPiGMYMkSosOJ3BQjDEAiwtO.jpg",
                                      release_date: "2019-12-10",
                                      overview: "At the height of the First World War, two young British soldiers, Schofield and Blake are given a seemingly impossible mission. In a race against time, they must cross enemy territory and deliver a message that will stop a deadly attack on hundreds of  own brother among them.",
                                      idMovie: "530915",
                                      videoKey: "0")
        callBack(movieEntity)
    }
}
