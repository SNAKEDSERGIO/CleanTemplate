//
//  ListMoviePresenter.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 1/27/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import Foundation

/// List Moview Module Presenter Protocol
protocol ListMoviePresenterProtocol : class {
    ///Funciones 1 elemento
//    func interactor(_ interactor: ListMovieInteractorProtocol, didFetch object: MovieEntity)
    
    ///Funciones WS
    func interactor(_ interactor: ListMovieInteractorProtocol, didFetch object: [MovieEntity])
    func searchAction()
    func saveFav(_ interactor: ListMovieInteractorProtocol, tag:(Int))
}

/// List Movie Module Presenter
class ListMoviePresenter {
    weak var view: ListMovieProtocol?
    var interactor: ListMovieInteractorProtocol?
}

/// List View Model
struct ListViewModel {
    var title: String
    var vote_average: String
    var poster_path: String
    var release_date: String
    var overview: String
    var idMovie: String
    var videoKey: String
}

// MARK: - extending ListMoviePresenter to implement it's protocol
extension ListMoviePresenter: ListMoviePresenterProtocol {
    ///Funciones WS
    func interactor(_ interactor: ListMovieInteractorProtocol, didFetch object: [MovieEntity]) {
        var movieArray: [ListViewModel] = []
        for i in 0..<object.count {
            let listViewModel = ListViewModel(title: object[i].title,
                                              vote_average: object[i].vote_average,
                                              poster_path: object[i].poster_path,
                                              release_date: object[i].release_date,
                                              overview: object[i].overview,
                                              idMovie: object[i].idMovie,
                                              videoKey: object[i].videoKey)
            movieArray.append(listViewModel)
        }

        view?.set(viewModel: movieArray)
    }
    ///Funciones 1 elemento
//    func interactor(_ interactor: ListMovieInteractorProtocol, didFetch object: MovieEntity) {
//        let listViewModel = ListViewModel(title: object.title, vote_average: object.vote_average, poster_path: object.poster_path, release_date: object.release_date, overview: object.overview, idMovie: object.idMovie, videoKey: object.videoKey)
//
//        view?.set(viewModel: listViewModel)
//
//    }
    
    func saveFav(_ interactor: ListMovieInteractorProtocol, tag:(Int)) {
        view?.saveFav(tag: tag)
    }
    
    func searchAction() {
        
    }
}

