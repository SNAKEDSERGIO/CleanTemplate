//
//  SearchPresenter.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/25/20.
//  Copyright (c) 2020 Sergio. All rights reserved.
//
//

//Presenter

import Foundation

///Presenter Protocol
protocol SearchPresenterProtocol: class {
    func interactor(_ interactor: SearchInteractor, didFetch object: [SearchEntity])
    func backAction()
    func transformModel(viewModel: ListViewModel)
}

class SearchPresenter  {
    weak var view: SearchViewControllerProtocol?
//    var interactor: SearchPresenterInteractorProtocol?
}

///Presenter Model
struct  SearchModel {
    var title: String
    var vote_average: String
    var poster_path: String
    var release_date: String
    var overview: String
    var idMovie: String
    var videoKey: String
}

///Presenter Extersion
extension SearchPresenter: SearchPresenterProtocol {
    func interactor(_ interactor: SearchInteractor, didFetch object:  [SearchEntity]) {
        var movieArray: [SearchModel] = []
        for i in 0..<object.count {
            let listViewModel = SearchModel(title: object[i].title,
                                              vote_average: object[i].vote_average,
                                              poster_path: object[i].poster_path,
                                              release_date: object[i].release_date,
                                              overview: object[i].overview,
                                              idMovie: object[i].idMovie,
                                              videoKey: object[i].videoKey)
            movieArray.append(listViewModel)
        }

        view?.set(viewModel: movieArray)
    }
    
    func backAction() {
        view?.backAction()
    }
    
    func transformModel(viewModel: ListViewModel) {
        view?.transformModel(viewModel: viewModel)
    }
}
