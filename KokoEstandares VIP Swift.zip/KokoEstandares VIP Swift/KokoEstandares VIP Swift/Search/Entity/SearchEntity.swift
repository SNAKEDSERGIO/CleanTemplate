//
//  SearchEntity.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/25/20.
//  Copyright (c) 2020 Sergio. All rights reserved.
//
//

import Foundation

/// Entity
struct SearchEntity {
    var title: String
    var vote_average: String
    var poster_path: String
    var release_date: String
    var overview: String
    var idMovie: String
    var videoKey: String
}
