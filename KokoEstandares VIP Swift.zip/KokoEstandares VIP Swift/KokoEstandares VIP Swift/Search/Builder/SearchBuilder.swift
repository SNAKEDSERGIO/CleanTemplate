//
//  SearchBuilder.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/25/20.
//  Copyright (c) 2020 Sergio. All rights reserved.
//
//

import Foundation

class SearchBuilder {
    
    class func builder(configView view:SearchViewController) {
        
        //MARK: Initialise components.
        let presenter = SearchPresenter()
        let interactor = SearchInteractor(withApiWorker: SearchWorker())
        
        //MARK: link VIP components.
        view.interactor = interactor
        view.presenter = presenter;
        presenter.view = view
        interactor.presenter = presenter
        
    }
    
}
