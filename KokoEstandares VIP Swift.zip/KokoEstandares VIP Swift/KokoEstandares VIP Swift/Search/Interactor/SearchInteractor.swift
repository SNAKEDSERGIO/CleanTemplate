//
//  SearchInteractor.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/25/20.
//  Copyright (c) 2020 Sergio. All rights reserved.
//
//

import Foundation
import UIKit

///InteractorProtocol
protocol SearchInteractorProtocol: class {
    func searchAction(searchText:(String), page:(String))
    func backAction()
    func transformModel(movieInfo:(SearchModel))
}

///Interactor
class SearchInteractor: SearchInteractorProtocol {
        
    var presenter: SearchPresenterProtocol?
    private var entity:[SearchEntity]?
    private let apiWorker: SearchWorker
    
    //Interactor init
    required init(withApiWorker apiWorker:SearchWorker) {
        self.apiWorker = apiWorker
    }
    
    ///InteractorProtocolFunction
    func searchAction(searchText:(String), page:(String)) {
        apiWorker.searchAction(searchText: searchText, page: page, callBack: { [unowned self] (SearchEntity) in
            self.entity = SearchEntity
            self.presenter?.interactor(self, didFetch: SearchEntity)
        })
    }
    
    func backAction() {
        self.presenter?.backAction()
    }
    
    func transformModel(movieInfo: (SearchModel)) {
        let listViewModel = ListViewModel(title: movieInfo.title,
        vote_average: movieInfo.vote_average,
        poster_path: movieInfo.poster_path,
        release_date: movieInfo.release_date,
        overview: movieInfo.overview,
        idMovie: movieInfo.idMovie,
        videoKey: movieInfo.videoKey)
        self.presenter?.transformModel(viewModel: listViewModel)
        
    }
    
    
}
