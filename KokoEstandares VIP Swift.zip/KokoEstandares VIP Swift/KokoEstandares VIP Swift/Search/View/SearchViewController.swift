//
//  SearchViewController.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/25/20.
//  Copyright (c) 2020 Sergio. All rights reserved.
//
//

//Viewcontroller

import UIKit
import NVActivityIndicatorView

//Viewcontroller Protocol
protocol SearchViewControllerProtocol: class {
    var presenter: SearchPresenterProtocol? { get set }
    var interactor: SearchInteractorProtocol? { get set }
    func set(viewModel: [SearchModel])
    func backAction()
    func transformModel(viewModel: ListViewModel)
}

//Viewcontroller IBActions, IBOutlets, Delegates
class SearchViewController: UIViewController, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource{
  
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var listMoviesTableView: UITableView!
    @IBOutlet weak var headerView: UIView!
    
    var presenter: SearchPresenterProtocol?
    var interactor: SearchInteractorProtocol?
    var searchMoviesArray: [SearchModel] = []
    let hud = Hud()
    var pageNumber:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchTextField.delegate = self;
        listMoviesTableView.delegate = self;
        listMoviesTableView.dataSource = self;
        
        listMoviesTableView.separatorStyle = .none
        
        listMoviesTableView.register(UINib(nibName: "MovieSearchTableViewCell", bundle: nil), forCellReuseIdentifier: "SearchCell")
        
        let tap = UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
        
        pageNumber = pageNumber + 1
        //Builder call
        SearchBuilder.builder(configView: self)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        headerView.layer.shadowColor = UIColor(red: 0.0 / 255.0, green: 32.0 / 255.0, blue: 56.0 / 255.0, alpha: 0.60).cgColor
        headerView.layer.shadowOffset = CGSize(width: 1, height: 2)
        headerView.layer.shadowOpacity = 1
        headerView.layer.shadowRadius = 5
    }
    
    //IBAction
    
    @IBAction func backAction(_ sender: Any) {
        // Interactor call
       interactor?.backAction()
    }
    
    @IBAction func searchAction(_ sender: Any) {
        //Hud init
        hud.showInView(view: self.view, type: .audioEqualizer, text: "Loading...", colorBackground: UIColor.black, colorTypeAndText: UIColor.white)
        // Interactor call
        searchTextField.resignFirstResponder()
        searchTextField.resignFirstResponder()
        if searchTextField.text == "" {
        } else {
            searchMoviesArray.removeAll()
            listMoviesTableView.isHidden = true
            listMoviesTableView.reloadData()
            pageNumber = 1
            interactor?.searchAction(searchText: searchTextField.text!, page: "\(pageNumber)")
        }
    }
    
    //UITableViewDelagates
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let viewHeader = UIView(frame: CGRect(x: 0, y: 0, width: listMoviesTableView.frame.size.width, height: 1.0))
        viewHeader.backgroundColor = UIColor.clear
        return viewHeader
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return searchMoviesArray.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchCell", for: indexPath) as! MovieSearchTableViewCell
        let movieModel = searchMoviesArray[indexPath.section]
        cell.selectionStyle = .none
        cell.posterImage.sd_setImage(with: URL(string: Constants.Constants.URL_POSTER_IMAGE + movieModel.poster_path), completed: nil)
        cell.posterImage.layer.cornerRadius = 5
        cell.titleMovieLabel.text = movieModel.title
        cell.overViewTextView.text = movieModel.overview
        cell.layer.shadowColor = UIColor(red: 0.0 / 255.0, green: 70.0 / 255.0, blue: 149.0 / 255.0, alpha: 0.60).cgColor
        cell.layer.shadowOffset = CGSize(width: 0, height: 4);
        cell.layer.shadowRadius = 3.0;
        cell.layer.shadowOpacity = 0.5;
        cell.layer.cornerRadius = 6;
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if (indexPath.section == searchMoviesArray.count - 1) && pageNumber < 4 {
            pageNumber = pageNumber + 1
            interactor?.searchAction(searchText: searchTextField.text!, page: "\(pageNumber)")
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let movieModel = searchMoviesArray[indexPath.section]
        interactor?.transformModel(movieInfo: movieModel)
    }
    
    //UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        hud.showInView(view: self.view, type: .audioEqualizer, text: "Loading...", colorBackground: UIColor.black, colorTypeAndText: UIColor.white)
        textField.resignFirstResponder()
        if searchTextField.text == "" {
        } else {
            searchMoviesArray.removeAll()
            listMoviesTableView.isHidden = true
            listMoviesTableView.reloadData()
           pageNumber = 1
           interactor?.searchAction(searchText: searchTextField.text!, page: "\(pageNumber)")
        }
        return false
    }
}

//Viewcontroller Extension
extension SearchViewController: SearchViewControllerProtocol {
    func set(viewModel: [SearchModel]) {
        for i in 0..<viewModel.count {
            searchMoviesArray.append(viewModel[i])
        }
        listMoviesTableView.isHidden = false
        listMoviesTableView.reloadData()
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) {
            //Hud dissmiss
            self.hud.dissmiss()
        }
    }
    
    func backAction() {
        _ = navigationController?.popViewController(animated: true)
    }
    
    func transformModel(viewModel: ListViewModel) {
        let vc = MovieDetailViewController(nibName: "MovieDetailViewController", bundle: nil)
        vc.movieInfo = viewModel
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
