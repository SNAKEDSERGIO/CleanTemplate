//
//  MovieDetailEntity.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/24/20.
//  Copyright (c) 2020 Sergio. All rights reserved.
//
//

import Foundation

/// Entity
struct MovieDetailEntity {
    var title: String
    var vote_average: String
    var poster_path: String
    var release_date: String
    var overview: String
    var idMovie: String
    var videoKey: String
}
