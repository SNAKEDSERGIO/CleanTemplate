//
//  MovieDetailInteractor.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/24/20.
//  Copyright (c) 2020 Sergio. All rights reserved.
//
//

import Foundation
import UIKit
import SafariServices

///InteractorProtocol
protocol MovieDetailInteractorProtocol: class {
    func startActionExample(movieInfo:(ListViewModel))
    func backAction()
    func videoAction()
    
}

///Interactor
class MovieDetailInteractor: MovieDetailInteractorProtocol {
    
    var presenter: MovieDetailPresenterProtocol?
    private var entity:MovieDetailEntity?
    private let apiWorker: MovieDetailWorkerProtocol
    
    //Interactor init
    required init(withApiWorker apiWorker:MovieDetailWorkerProtocol) {
        self.apiWorker = apiWorker
    }
    
    ///InteractorProtocolFunction
    func startActionExample(movieInfo: (ListViewModel)) {
        apiWorker.getMovieDetail(movieInfoModel: movieInfo, callBack: { [unowned self] (movieEntityVar) in
            self.entity = movieEntityVar
            self.presenter?.interactor(self, didFetch: movieEntityVar)
        })
    }
    
    func backAction() {
        self.presenter?.backAction()
    }
    
    func videoAction() {
        self.presenter?.videoAction(self, didFetch: self.entity!)
    }
    
}
