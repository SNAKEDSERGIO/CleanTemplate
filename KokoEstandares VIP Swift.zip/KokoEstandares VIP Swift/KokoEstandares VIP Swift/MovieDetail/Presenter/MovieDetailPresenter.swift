//
//  MovieDetailPresenter.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/24/20.
//  Copyright (c) 2020 Sergio. All rights reserved.
//
//

//Presenter

import Foundation

///Presenter Protocol
protocol MovieDetailPresenterProtocol: class {
    func interactor(_ interactor: MovieDetailInteractor, didFetch object: MovieDetailEntity)
    func backAction()
    func videoAction(_ interactor: MovieDetailInteractor, didFetch object: MovieDetailEntity)
}

class MovieDetailPresenter  {
    weak var view: MovieDetailViewControllerProtocol?
//    var interactor: MovieDetailPresenterInteractorProtocol?
}

///Presenter Model
struct  MovieDetailModel {
    var title: String
    var vote_average: String
    var poster_path: String
    var release_date: String
    var overview: String
    var idMovie: String
    var videoKey: String
}

///Presenter Extersion
extension MovieDetailPresenter: MovieDetailPresenterProtocol {
    func interactor(_ interactor: MovieDetailInteractor, didFetch object:  MovieDetailEntity) {
        let model =  MovieDetailModel(title: object.title, vote_average: object.vote_average, poster_path: object.poster_path, release_date: object.release_date, overview: object.overview, idMovie: object.idMovie, videoKey: object.videoKey)
        view?.set(viewModel: model)
    }
    
    func backAction() {
        view?.backAction()
    }
    
    func videoAction(_ interactor: MovieDetailInteractor, didFetch object:  MovieDetailEntity) {
        let model =  MovieDetailModel(title: object.title, vote_average: object.vote_average, poster_path: object.poster_path, release_date: object.release_date, overview: object.overview, idMovie: object.idMovie, videoKey: object.videoKey)
        view?.videoAction(viewModel: model)
    }
}
