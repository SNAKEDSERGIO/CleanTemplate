//
//  MovieDetailWorker.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/24/20.
//  Copyright (c) 2020 Sergio. All rights reserved.
//
//

//Worker
import Foundation
import Alamofire

//Worker Protocol
protocol MovieDetailWorkerProtocol: class {
    func getMovieDetail(movieInfoModel:(ListViewModel), callBack:@escaping (MovieDetailEntity) -> Void)
}

class MovieDetailWorker: MovieDetailWorkerProtocol {
    func getMovieDetail(movieInfoModel: (ListViewModel), callBack: @escaping (MovieDetailEntity) -> Void) {
        let url = URL(string: "\(Constants.Constants.URL_MOVIE_VIDEO_START)" + movieInfoModel.idMovie + "\(Constants.Constants.URL_MOVIE_VIDEO_MIDDLE)" + "\(Constants.Constants.API_KEY_TMDB)" + "\(Constants.Constants.URL_MOVIE_VIDEO_END)")!
        AF.request(url).validate().responseJSON { response in
            switch response.result {
                case .success:
                    if let JSON = response.value as? [String: Any] {
                        let data = JSON["results"] as! [NSDictionary]
                        if data.count == 0 {
                            let movieInfo = MovieDetailEntity(title: movieInfoModel.title, vote_average: movieInfoModel.vote_average, poster_path: movieInfoModel.poster_path, release_date: movieInfoModel.release_date, overview: movieInfoModel.overview, idMovie: movieInfoModel.idMovie, videoKey: "")
                            callBack(movieInfo)
                        } else {
                            let videoKey = data[0].object(forKey: "key")
                            let movieInfo = MovieDetailEntity(title: movieInfoModel.title, vote_average: movieInfoModel.vote_average, poster_path: movieInfoModel.poster_path, release_date: movieInfoModel.release_date, overview: movieInfoModel.overview, idMovie: movieInfoModel.idMovie, videoKey: videoKey as! String)
                            callBack(movieInfo)
                        }
                    }
                case .failure(let error):
                    print(error)
                }
        }
    }
}
