//
//  MovieDetailBuilder.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/24/20.
//  Copyright (c) 2020 Sergio. All rights reserved.
//
//

import Foundation

class MovieDetailBuilder {
    
    class func builder(configView view:MovieDetailViewController) {
        
        //MARK: Initialise components.
        let presenter = MovieDetailPresenter()
        let interactor = MovieDetailInteractor(withApiWorker: MovieDetailWorker())
        
        //MARK: link VIP components.
        view.interactor = interactor
        view.presenter = presenter;
        presenter.view = view
        interactor.presenter = presenter
        
    }
    
}
