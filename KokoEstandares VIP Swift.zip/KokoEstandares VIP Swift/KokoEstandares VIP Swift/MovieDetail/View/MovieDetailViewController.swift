//
//  MovieDetailViewController.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 2/24/20.
//  Copyright (c) 2020 Sergio. All rights reserved.
//
//

//Viewcontroller

import UIKit
import SafariServices
import NVActivityIndicatorView

//Viewcontroller Protocol
protocol MovieDetailViewControllerProtocol: class {
    var presenter: MovieDetailPresenterProtocol? { get set }
    var interactor: MovieDetailInteractorProtocol? { get set }
    func set(viewModel: MovieDetailModel)
    func backAction()
    func videoAction(viewModel: MovieDetailModel)
}

//Viewcontroller IBActions, IBOutlets, Delegates
class MovieDetailViewController: UIViewController{
    @IBOutlet weak var movieNameLabel: UILabel!
    @IBOutlet weak var posterImage: UIImageView!
    @IBOutlet weak var scrollDetail: UIScrollView!
    @IBOutlet weak var overviewLabel: UILabel!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var videoButton: UIButton!
    
    var presenter: MovieDetailPresenterProtocol?
    var interactor: MovieDetailInteractorProtocol?
    var movieInfo: ListViewModel?
    let hud = Hud()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Hud init
        hud.showInView(view: self.view, type: .audioEqualizer, text: "Loading...", colorBackground: UIColor.black, colorTypeAndText: UIColor.white)

        movieNameLabel.text = movieInfo?.title
        posterImage.layer.cornerRadius = 5
        
        //Builder call
        MovieDetailBuilder.builder(configView: self)
        
        // Interactor call
        interactor?.startActionExample(movieInfo: movieInfo!)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        headerView.layer.shadowColor = UIColor(red: 0.0 / 255.0, green: 32.0 / 255.0, blue: 56.0 / 255.0, alpha: 0.60).cgColor
        headerView.layer.shadowOffset = CGSize(width: 1, height: 2)
        headerView.layer.shadowOpacity = 1
        headerView.layer.shadowRadius = 5
    }
    
    //IBAction
    @IBAction func returnAction(_ sender: Any) {
        interactor?.backAction()
    }
    
    @IBAction func videoAction(_ sender: Any) {
        interactor?.videoAction()
    }
}


//Viewcontroller Extension
extension MovieDetailViewController: MovieDetailViewControllerProtocol {
    func set(viewModel: MovieDetailModel) {
        posterImage.sd_setImage(with: URL(string: Constants.Constants.URL_POSTER_IMAGE + viewModel.poster_path), completed: nil)
        overviewLabel.text = viewModel.overview
        if viewModel.videoKey == "" {
            videoButton.isHidden = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) {
            //Hud dissmiss
            self.hud.dissmiss()
        }
    }
    
    func backAction() {
        _ = navigationController?.popViewController(animated: true)
    }
    
    func videoAction(viewModel: MovieDetailModel) {
        if let url = URL(string: "https://youtu.be/" + viewModel.videoKey) {
            let config = SFSafariViewController.Configuration()
            config.entersReaderIfAvailable = true

            let vc = SFSafariViewController(url: url, configuration: config)
            present(vc, animated: true)
        }
    }
}
