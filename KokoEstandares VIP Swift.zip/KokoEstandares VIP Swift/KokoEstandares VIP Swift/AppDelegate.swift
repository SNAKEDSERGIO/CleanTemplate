//
//  AppDelegate.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 1/23/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit
import RealmSwift

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        Realm.Configuration.defaultConfiguration = Realm.Configuration(
            schemaVersion: 1,
            migrationBlock: { migration, oldSchemaVersion in
                if (oldSchemaVersion < 1) {
                   //write the migration logic here
                }
        })
        
        
        
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.makeKeyAndVisible()

        let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewController") as UIViewController
//        let listmovieView = ListMoviesView(nibName: "ListMoviesView", bundle: nil)
        let navController = UINavigationController(rootViewController: viewController) // Integrate navigation controller programmatically if you want
        navController.isNavigationBarHidden = true;
        window?.rootViewController = navController
        
        return true
    }

}

