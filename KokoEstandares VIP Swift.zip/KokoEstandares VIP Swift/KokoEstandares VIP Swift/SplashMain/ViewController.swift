//
//  ViewController.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 1/23/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var interactor: ViewControlerRouterDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            let vc = ListMoviesView(nibName: "ListMoviesView", bundle: nil)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

