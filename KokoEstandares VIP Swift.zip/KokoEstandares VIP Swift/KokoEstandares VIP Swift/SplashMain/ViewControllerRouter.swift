//
//  ViewControllerRouter.swift
//  KokoEstandares VIP Swift
//
//  Created by Sergio on 1/24/20.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

protocol ViewControlerRouterDelegate {
    func navigationRouter(viewController: UINavigationController)
}

class ViewControllerRouter: NSObject {

    // MARK: Navigation
    func navigationRouter(viewController: UINavigationController) {
        let vc = MovieDetailViewController(nibName: "MovieDetailViewController", bundle: nil)
        viewController.pushViewController(vc, animated: true)
    }
}
